<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>TerrTwi</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    
</head>

<body>
    <div class="login-dark">
        <form method="post">
            <h2 class="sr-only">Se connecter</h2>
            

            <?php
				include('classes/database.php');
				include('classes/classlogin.php');


				if(Login::LoggedIn())
				{
					if(isset($_POST['changepassword']))
					{
						$oldpasswd = $_POST['oldpassword'];
						$newpasswd = $_POST['newpassword'];
						$newpasswdrpt = $_POST['newpasswordrepeat'];
						$user_id = Login::LoggedIn();

						if(password_verify($oldpasswd, DB::query('SELECT passwd FROM utilisateur WHERE id=:user_id', array(':user_id'=>$user_id))[0]['passwd']))
						{
							
							if($newpasswd == $newpasswdrpt)
							{
								
								if(strlen($newpasswd) >= 6 && strlen($newpasswd) <= 60)
								{
									DB::query('UPDATE utilisateur SET passwd=:newpassword WHERE id=:user_id', array(':newpassword'=>password_hash($newpasswd, PASSWORD_BCRYPT), ':user_id'=>$user_id));
									echo "<p><center>Mot de passe changé</p></center>";
								}
							}
							else{
								echo "<p><center>Mot de passe différents</p></center>";
							}
						}
						else{
							echo "<p><center>Ancien mot de passe incorrect</p></center>";
						}
					}
				}
				else {
					header('Location: notloggedin.php');
				}
			?>
            <div class="form-group"><input class="form-control" type="password" name="oldpassword" value="" placeholder="Mot de passe actuel"></div>
            <div class="form-group"><input class="form-control" type="password" name="newpassword" value="" placeholder="Nouveau mot de passe"></div>
            <div class="form-group"><input class="form-control" type="password" name="newpasswordrepeat" value="" placeholder="Confirmer"></div>
            <div class="form-group"><input class="btn btn-primary btn-block" type="submit" name="changepassword" value="Changer le mot de passe"></button></div>
        </form>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>
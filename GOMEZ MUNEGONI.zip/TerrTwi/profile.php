<?php
include('classes/database.php');
include('classes/classlogin.php');
include('classes/classpost.php');

if(!Login::LoggedIn())
{
	header('Location: notloggedin.php');
}

$username = "";
$isFollowing = False;
if(isset($_GET['username']))
{
	if (DB::query('SELECT username FROM utilisateur WHERE username=:username', array(':username'=>$_GET['username'])))
	{
		$username = DB::query('SELECT username FROM utilisateur WHERE username=:username', array(':username'=>$_GET['username']))[0]['username'];
		$userid = DB::query('SELECT id FROM utilisateur WHERE username=:username', array(':username'=>$_GET['username']))[0]['id'];
        $followerid = Login::LoggedIn();

		
		if(isset($_POST['follow'])) 
		{
			
			if ($userid != $followerid) 
			{
				if (!DB::query('SELECT folowid FROM followers WHERE user_id=:userid AND folowid=:followerid', array(':userid'=>$userid, ':followerid'=>$followerid)))
				{
					
					DB::query('INSERT INTO followers VALUES (\'\', :userid, :followerid)', array(':userid'=>$userid, ':followerid'=>$followerid));
				} else {
					echo 'Utilisateur déjà suivi !';
				}
				$isFollowing = True;
			}
		}
		
		if (isset($_POST['unfollow'])) 
		{
			
			if ($userid != $followerid)
			{
				if (DB::query('SELECT folowid FROM followers WHERE user_id=:userid AND folowid=:followerid', array(':userid'=>$userid, ':followerid'=>$followerid)))
				{
					
					DB::query('DELETE FROM followers WHERE user_id=:userid AND folowid=:followerid', array(':userid'=>$userid, ':followerid'=>$followerid));
                }
				$isFollowing = False;
			}
		}
        if (DB::query('SELECT folowid FROM followers WHERE user_id=:userid AND folowid=:followerid', array(':userid'=>$userid, ':followerid'=>$followerid))) {
			$isFollowing = True;
        }

		if (isset($_POST['deletepost']))
		{
			if (DB::query('SELECT id FROM posts WHERE id=:postid AND user_id=:userid', array(':postid'=>$_GET['postid'], ':userid'=>$followerid)))
			{
				DB::query('DELETE FROM posts WHERE id=:postid and user_id=:userid', array(':postid'=>$_GET['postid'], ':userid'=>$followerid));
                DB::query('DELETE FROM post_likes WHERE post_id=:postid', array(':postid'=>$_GET['postid']));
                echo 'Post supprimé !';
			}
		}
		
		if(isset($_POST['post']))
		{
			Post::createPost($_POST['postbody'], Login::LoggedIn(), $userid);
		}

		if(isset($_GET['postid']) && !isset($_POST['deletepost']))
		{
			Post::likePost($_GET['postid'], $followerid);
		}

		$posts = Post::displaypost($userid, $username, $followerid);

	}
	else{
		die('Utilisateur introuvable');
	}
}

?>

<h1>Profile de <?= htmlspecialchars($username);  ?></h1>
<form action="profile.php?username=<?= htmlspecialchars($username);?>" method="post">
		<?php
		
		if ($userid != $followerid) {
                if ($isFollowing) {
                        echo '<input type="submit" name="unfollow" value="Arrêter de suivre">';
                } else {
                        echo '<input type="submit" name="follow" value="Suivre">';
                }
        }
		?>

</form>
<form action="profile.php?username=<?= htmlspecialchars($username);?>" method="post">
	<textarea name="postbody" rows="8" cols="80"></textarea>
	<input type="submit" name="post" value="Poster">
</form>


<div class="posts">
	<?= htmlspecialchars_decode($posts); ?>
	</br>
</div>
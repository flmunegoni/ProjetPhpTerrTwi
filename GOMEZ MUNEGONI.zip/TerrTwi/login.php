<?php
include('classes/database.php');

?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>TerrTwi</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
   
        <form action="login.php" method="post">
            <h2 class="sr-only">Login Form</h2>
            
            <?php 
                if(isset($_POST['login'])){
	            $username = $_POST['username'];
                $passwd = $_POST['password'];

	            if (DB::query('SELECT username FROM utilisateur WHERE username=:username', array(':username'=>$username)))
	            {
		            
		            if (password_verify($passwd, DB::query('SELECT passwd FROM utilisateur WHERE username=:username', array(':username'=>$username))[0]['passwd']))
		            {
			        echo "Vous êtes entré sur le site";

			        $cstrong = True;
                    $token = bin2hex(openssl_random_pseudo_bytes(64, $cstrong));
                    $userid = DB::query('SELECT id FROM utilisateur WHERE username=:username', array(':username'=>$username))[0]['id'];
                    DB::query('INSERT INTO toklog VALUES (\'\', :token, :userid)', array(':token'=>sha1($token), ':userid'=>$userid));

			       
			        setcookie("SNICK", $token, time() + 360, '/', NULL, NULL, TRUE);
			        setcookie("SNIP", '1', time() + 330, '/', NULL, NULL, TRUE);

                
                    header('Location: index.php');
		            }
		            else{
			            echo "<center><p>Mot de passe incorrect </p></center>";
		            }
	            }
	            else{
		            echo "<center><p>Vous n'avez pas de compte</p></center>";
	            }
}           ?>
            <div class="form-group"><input class="form-control" type="text" name="username" placeholder="Nom"></div>
            <div class="form-group"><input class="form-control" type="password" id="password" name="password" placeholder="Mot de passe"></div>
            <div class="form-group"><input class="btn btn-primary btn-block" type="submit" name="login" value="Login"></button></div><a class="forgot" href="crecompte.php">Pas de compte?</a>
            </br>
            <a class="forgot" href="#">Mot de passe oublié?</a></form>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/bs-init.js"></script>
</body>

</html>
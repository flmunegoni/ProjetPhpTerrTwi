GOMEZ Alexis
MUNEGONI Flora

-créer un compte,
-se connecter,
-espace personnel,
-page de profil publique avec affichage des tweet,
-suivis d'utilisateurs
-like de tweet,
-seule la personne qui a créer le tweet peut modif ou supp
-timeline tentéee mais abandonnée...

repository : https://github.com/flmunegoni/ProjetPhpTerrTwi.git
url à rentrer dans le navigateur: localhost/TerrTwi



Nous tenons à préciser que nous avons fait le site en suivant de notre mieux des vidéos sur internet et des tutos, certaines fonctionnalités
ne marchaient pas pour nous lors du visionnage des vidéos (timeline...), donc par manque de temps, nous avons fait le tutoriel et laissé les choses qui ont marchées. 
Nous précisons ça car il se peut que d'autres élèves aient suvi les vidéos compte tenu du contexte, et que de ce fait, plusieurs codes peuvent être similaires.
Nous avons essayé d'adpater le code au mieux et au plus simple, video (howcode socialnetwork sur ytb)






<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>TerrTwi</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
   
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
    
        <form method="post">
            <h2 class="sr-only">Se connecter</h2>
            
            <?php
                include('classes/database.php');

                if (isset($_POST['createaccount'])) {

                $username = $_POST['username'];
                $passwd = $_POST['password'];
                $email = $_POST['email'];

             
                if (!DB::query('SELECT username FROM utilisateur WHERE username=:username', array(':username'=>$username)))
                {
                   
                    if(strlen($username) >= 3 && strlen($username) <= 32)
                    {
             
                        if (preg_match('/^[a-zA-Z0-9]*_?[a-zA-Z0-9]*$/', $username))
                  
                            if(strlen($passwd) >= 6 && strlen($passwd) <= 60)
                            {
                              
                                if(filter_var($email, FILTER_VALIDATE_EMAIL))
                                {
                                    if((!DB::query('SELECT email FROM utilisateur WHERE email=:email', array(':email'=>$email))))
                                    {
                                        DB::query('INSERT INTO utilisateur VALUES (\'\', :username, :passwd, :email)', array(':username'=>$username, ':passwd'=>password_hash($passwd, PASSWORD_BCRYPT), ':email'=>$email));
                                        header('Location: login.php');
                                        echo "Succès!";
								    }
                                    else{
                                        echo "<center><p>Email utilisé</p></center>";
								    }
						        }
                                else{
                                    echo "<center><p>Email inavlide</p></center>";
						        }
						    }
                            else{
                                echo "<center><p>Mot de passe invalide</p></center>";
						    }
                        }
                        else{
                            echo "<center><p>Nom invalide</p></center>";                        
					    }
				    }
                    else{
                        echo "<center><p>Nom invalide</p></center>";        
				    }
		        }
                else {
                    echo "<center><p>Nom déjà utilisé</p></center>";  
	            }
            

            ?>
            <div class="form-group"><input class="form-control" type="text" name="username" value="" placeholder="Nom"></div>
            <div class="form-group"><input class="form-control" type="password" name="password" value="" placeholder="Mot de passe"></div>
            <div class="form-group"><input class="form-control" type="email" name="email" placeholder="Email"></div>
            <div class="form-group"><input class="btn btn-primary btn-block" type="submit"  name="createaccount" value="Créer un compte"></button></div><a class="forgot" href="login.php">Vous avez un compte?</a></form>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>
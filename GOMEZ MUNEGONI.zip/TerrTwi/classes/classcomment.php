<?php

class Comment{

	public static function createComment($commentbody, $postId, $userId)
	{
	
		if(strlen($commentbody)>160 || strlen($commentbody)<1)
		{
			die('Post invalide');
		}

		if(!DB::query('SELECT id FROM posts WHERE id=:postid', array(':postid'=>$postId)))
		{
			echo "ID de post invalide";
		}
		else{
			DB::query('INSERT INTO comments VALUES (\'\', :comment, :userid, NOW(), :postid)', array(':comment'=>$commentbody, ':userid'=>$userId, ':postid'=>$postId));
		}
	}

	public static function displayComment($postId)
	{
		$comments = DB::query('SELECT comments.comment, utilisateur.username FROM comments, utilisateur WHERE post_id = :postid AND comments.user_id = utilisateur.id ORDER BY comments.id DESC', array(':postid'=>$postId));
		foreach($comments as $comment)
		{
			echo $comment['comment']." ~ ".$comment['username']."<hr />";
		}
	}
}


?>
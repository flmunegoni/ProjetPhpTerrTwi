<?php

class Post {

	public static function createPost($postbody, $loggedinuserid, $profileid)
	{
		
		if(strlen($postbody)>160 || strlen($postbody)<1)
		{
			die('Post invalide');
		}

		
		if ($loggedinuserid == $profileid)
		{
			DB::query('INSERT INTO posts VALUES (\'\', :postbody, NOW(), :userid, 0)', array(':postbody'=>$postbody, ':userid'=>$profileid));
		}
		else{
			die('Vous ne pouvez pas poster sur un autre profil!!!');
		}
	}

	public static function likePost($postid, $likeid)
	{
		
		if(!DB::query('SELECT user_id FROM post_likes WHERE post_id=:postid AND user_id=:userid', array(':postid'=>$postid, ':userid'=>$likeid)))
		{
			DB::query('UPDATE posts SET likes=likes+1 WHERE id=:postid', array(':postid'=>$postid));
			DB::query('INSERT INTO post_likes VALUES (\'\', :postid, :userid)', array(':postid'=>$postid, ':userid'=>$likeid));
		}
		else{
			DB::query('UPDATE posts SET likes=likes-1 WHERE id=:postid', array(':postid'=>$postid));
			DB::query('DELETE FROM post_likes WHERE post_id=:postid AND user_id=:userid', array(':postid'=>$postid, ':userid'=>$likeid));
		}

	}

	public static function displaypost ($userid, $username, $loggedinuserid)
	{
		
		$dbposts = DB::query('SELECT * FROM posts WHERE user_id=:userid ORDER BY id DESC', array(':userid'=>$userid));
		$posts = "";
		
		foreach($dbposts as $p)
		{
			
			if (!DB::query('SELECT post_id FROM post_likes WHERE post_id=:postid AND user_id=:userid', array(':postid'=>$p['id'], ':userid'=>$loggedinuserid)))
			{
			
				$posts .= htmlspecialchars($p['body'])."
				<form action='profile.php?username=$username&postid=".$p['id']."' method='post'>
					<input type='submit' name='like' value='Like'>
					<span>".$p['likes']." likes</span>
				";
				if($userid == $loggedinuserid)
				{
					$posts .= "<input type='submit' name='deletepost' value='x' />";
				}
				$posts .= "
				</form><hr /></br />
				";
			}
			else{
			
				$posts .= htmlspecialchars($p['body'])."
				<form action='profile.php?username=$username&postid=".$p['id']."' method='post'>
					<input type='submit' name='unlike' value='Unlike'>
					<span>".$p['likes']." likes</span>
				";
				if($userid == $loggedinuserid)
				{
					$posts .= "<input type='submit' name='deletepost' value='x' />";
				}
				$posts .= "
				</form><hr /></br />
				";
			}
		}
		return $posts;
	}
}

?>
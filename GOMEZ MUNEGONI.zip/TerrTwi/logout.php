<?php
include('classes/database.php');
include('classes/classlogin.php');

if(!Login::LoggedIn())
{
	header('Location: notloggedin.php');
}

if(isset($_POST['confirm']))
{
	if(isset($_POST['alldevices']))
	{
		DB::query('DELETE FROM toklog WHERE userid=:user_id', array(':user_id'=>Login::LoggedIn()));
	}
	else{
		if(isset($_COOKIE['SNICK']))
		{
			DB::query('DELETE FROM toklog WHERE token=:token', array(':token'=>sha1($_COOKIE['SNICK'])));
		}
		setcookie('SNICK', '1', time()-3600);
		setcookie('SNIP', '1', time()-3600);
	}
}

?>

<h1>Se déconnecter?</h1>
<p>Vous êtes sûrs ?</p>
<form action="logout.php" method="post">
	<input type="checkbox" name="alldevices" value="alldevices">Se déconnecter de tous les appareils?<br />
	<input type="submit" name="confirm" value="confirmer"<p />
</form>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>TerrTwI</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    
    <link rel="stylesheet" href="assets/css/Login-Form-Dark.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
    
        <form method="post">
            <h2 class="sr-only">Login</h2>
            

            <?php
			    die ("<p><center>Non connecté</p></center> <a class='forgot' href='login.php'>Se connecter ?</a>");
			?>
            <div class="form-group"><input class="form-control" type="password" name="oldpassword" value="" placeholder="Mot de passe actuel"></div>
            <div class="form-group"><input class="form-control" type="password" name="newpassword" value="" placeholder="Nouveau mot de passe "></div>
            <div class="form-group"><input class="form-control" type="password" name="newpasswordrepeat" value="" placeholder="Confirmer"></div>
            <div class="form-group"><input class="btn btn-primary btn-block" type="submit" name="changepassword" value="Changer le mot de passe"></button></div>
        </form>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>